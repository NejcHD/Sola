﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Media;

namespace VarnostNaloga2
{
    public partial class MainWindow : Window
    {

        private Dictionary<char, char> kljuc = new Dictionary<char, char>();

        public MainWindow()
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            InitializeComponent();
            PonastaviKljuc();
        }

        private void PonastaviKljuc()
        {
            string abeceda = "abcčdefghijklmnoprsštuvzž";
            kljuc.Clear();
            foreach (char c in abeceda)
                kljuc[c] = c;
        }

        // FREKVENCA
        private Dictionary<char, int> IzracunajFrekvenco(string tekst)
        {
            var frekvence = new Dictionary<char, int>();

            foreach (char c in tekst.ToLower())
            {
                if (char.IsLetter(c))
                {
                    if (frekvence.ContainsKey(c)) frekvence[c]++;
                    else frekvence[c] = 1;
                }
            }

            return frekvence;
        }

        private List<char> PridobiUrejeneCrkePoFrekvenci(string tekst)
        {
            return IzracunajFrekvenco(tekst)
                .OrderByDescending(x => x.Value)
                .Select(x => x.Key)
                .ToList();
        }

        // GRAF 
        private void NarisiGraf(string tekst)
        {
            grafCanvas.Children.Clear();

            var frekvence = IzracunajFrekvenco(tekst);
            if (frekvence.Count == 0) return;

            double sirina = grafCanvas.ActualWidth;
            double visina = grafCanvas.ActualHeight;

            if (sirina == 0 || visina == 0)
            {
                grafCanvas.UpdateLayout();
                sirina = grafCanvas.ActualWidth;
                visina = grafCanvas.ActualHeight;
            }

            double max = frekvence.Values.Max();
            double stolpecSirina = sirina / frekvence.Count;

            int i = 0;
            foreach (var par in frekvence.OrderByDescending(x => x.Value))
            {
                double h = (par.Value / max) * (visina - 30);

                Rectangle rect = new Rectangle
                {
                    Width = stolpecSirina - 4,
                    Height = h,
                    Fill = Brushes.Blue
                };

                Canvas.SetLeft(rect, i * stolpecSirina);
                Canvas.SetTop(rect, visina - h - 20);

                grafCanvas.Children.Add(rect);

                TextBlock txt = new TextBlock
                {
                    Text = par.Key.ToString()
                };

                Canvas.SetLeft(txt, i * stolpecSirina);
                Canvas.SetTop(txt, visina - 20);

                grafCanvas.Children.Add(txt);

                i++;
            }
        }

        private void PosodobiDesifriranje()
        {
            StringBuilder sb = new StringBuilder();

            foreach (char c in txtSifrirano.Text)
            {
                char lower = char.ToLower(c);

                if (kljuc.ContainsKey(lower))
                {
                    char nova = kljuc[lower];
                    sb.Append(char.IsUpper(c) ? char.ToUpper(nova) : nova);
                }
                else sb.Append(c);
            }

            txtDesifrirano.Text = sb.ToString();
            NarisiGraf(txtDesifrirano.Text);
        }

        // NALOŽI ŠIFROPIS 
        private void btnNaloziSif_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == true)
            {
                txtSifrirano.Text = PreberiDatoteko(ofd.FileName);
                PonastaviKljuc();
                PosodobiDesifriranje();
                NarisiGraf(txtSifrirano.Text);
            }
        }

        // NALOŽI REFERENCO
        private void btnNaloziRef_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == true)
            {
                string refText = PreberiDatoteko(ofd.FileName);
                string sifText = txtSifrirano.Text;

                if (string.IsNullOrWhiteSpace(sifText))
                {
                    MessageBox.Show("Najprej naloži šifropis!");
                    return;
                }

                var refCrke = PridobiUrejeneCrkePoFrekvenci(refText);
                var sifCrke = PridobiUrejeneCrkePoFrekvenci(sifText);

                PonastaviKljuc();

                int meja = Math.Min(refCrke.Count, sifCrke.Count);

                for (int i = 0; i < meja; i++)
                {
                    kljuc[sifCrke[i]] = refCrke[i];
                }

                PosodobiDesifriranje();
                NarisiGraf(refText);

                MessageBox.Show("Frekvenčna analiza končana!");
            }
        }

        // zamenjaj 
        private void btnZamenjaj_Click(object sender, RoutedEventArgs e)
        {
            if (txtOd.Text.Length == 0 || txtV.Text.Length == 0) return;

            char a = char.ToLower(txtOd.Text[0]);
            char b = char.ToLower(txtV.Text[0]);

            if (!kljuc.ContainsKey(a)) return;

            char keyB = kljuc.FirstOrDefault(x => x.Value == b).Key;

            if (keyB != '\0')
            {
                char temp = kljuc[a];
                kljuc[a] = b;
                kljuc[keyB] = temp;
            }

            PosodobiDesifriranje();
        }

        // SHRANI
        private void btnShrani_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();

            if (sfd.ShowDialog() == true)
            {
                File.WriteAllText(sfd.FileName, txtDesifrirano.Text, Encoding.UTF8);
            }
        }

        private string PreberiDatoteko(string pot)
        {
            
            string text = File.ReadAllText(pot, Encoding.UTF8);

            if (!text.Contains("�"))
                return text;

            
            text = File.ReadAllText(pot, Encoding.GetEncoding(1250));

            if (!text.Contains("�"))
                return text;

      
            text = File.ReadAllText(pot, Encoding.Unicode);

            return text;
        }
    }
}