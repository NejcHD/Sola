﻿using Backend.Entitete;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;

namespace Backend.Endpoints
{
    public class Sporocila
    {
        public static void MapApi(WebApplication app)
        {

            /*
            Pridobi seznam sporočil
            200 OK: List<Sporocilo>
            */
            app.MapGet("/sporocila", async () =>
            {
                await using var db = new BazaContext();
                var sporocila = await db.Sporocila
                    .ToListAsync();
                return Results.Ok(sporocila);
            });

            /*
            Pridobi sporočilo po ID
            Vrne eno sporočilo skupaj s pošiljateljem in prejemnikom.
            OK: Sporocilo
            Not Found
            */

            app.MapGet("/sporocila/{id:int}",
                async (int id) =>
            {
                await using var db = new BazaContext();
                var sporocilo = await db.Sporocila
                    .FirstOrDefaultAsync(s => s.Id == id);

                return sporocilo is null ? Results.NotFound() : Results.Ok(sporocilo);
            });

        }
    }
}
